<?php
require_once 'db.php';

$category = isset($_GET['category']) ? $_GET['category'] : '';
$minPrice = isset($_GET['minPrice']) ? (float)$_GET['minPrice'] : 0;
$maxPrice = isset($_GET['maxPrice']) ? (float)$_GET['maxPrice'] : 9999999;
$search = isset($_GET['search']) ? $db->real_escape_string($_GET['search']) : '';
$sql = "SELECT * FROM products WHERE 1=1"; 

if ($category != "") {
    $sql = $sql . " AND category = '" . $db->real_escape_string($category) . "'";
}

if ($minPrice > 0) {
    $sql .= " AND price >= " . $minPrice;
}

if ($maxPrice < 9999999) {
    $sql = $sql . " AND price <= " . $maxPrice;
}

if ($search != "") {
    $sql = $sql . " AND name LIKE '%" . $db->real_escape_string($search) . "%'";
}
$result = $db->query($sql);

if (!$result) {
    echo "Ошибка выполнения запроса: " . $db->error;
    exit; 
}
$categorySql = "SELECT DISTINCT category FROM products";
$categoryResult = $db->query($categorySql);
$categories = array(); 

while ($row = $categoryResult->fetch_assoc()) {
    $categories[] = $row['category'];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Product Filtering</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>Product Filter</h1>

<form method="get">
    <label for="category">Category:</label>
    <select name="category" id="category">
        <option value="">All</option>
        <?php foreach ($categories as $cat): ?>
            <option value="<?php echo $cat; ?>" <?php if ($category == $cat) echo 'selected'; ?>><?php echo $cat; ?></option>
        <?php endforeach; ?>
    </select><br><br>

    <label for="minPrice">Min Price:</label>
    <input type="number" name="minPrice" id="minPrice" value="<?php echo $minPrice; ?>"><br><br>

    <label for="maxPrice">Max Price:</label>
    <input type="number" name="maxPrice" id="maxPrice" value="<?php echo ($maxPrice == 9999999 ? '' : $maxPrice); ?>"><br><br>

    <label for="search">Search:</label>
    <input type="text" name="search" id="search" value="<?php echo $search; ?>"><br><br>

    <input type="submit" value="Filter">
</form>

<h2>Products</h2>
<table>
<thead>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Category</th>
        <th>Price</th>
    </tr>
</thead>
<tbody>
<?php while ($row = $result->fetch_assoc()): ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['category']; ?></td>
        <td><?php echo $row['price']; ?></td>
    </tr>
<?php endwhile; ?>
</tbody>
</table>
<?php
$db->close();
?>
</body>
</html>