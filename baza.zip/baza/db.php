<?php
$servername = '192.168.199.13';
$username = 'learn';
$password = 'learn';
$dbname = 'learn_is364-Odegov';
$db = new mysqli($servername, $username, $password, $dbname);
?>

